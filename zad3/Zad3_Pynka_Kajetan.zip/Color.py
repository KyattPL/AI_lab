import enum

class Color(enum.Enum):
    White = 1
    Black = 2