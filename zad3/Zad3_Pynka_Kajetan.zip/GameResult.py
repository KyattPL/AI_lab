from enum import Enum

class GameResult(Enum):
    WHITE_WIN=1
    BLACK_WIN=2
    TIE=3